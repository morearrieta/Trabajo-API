package com.example.persona;

import com.example.persona.entities.Persona;
import com.example.persona.repositories.PersonaRepository;
import org.hibernate.validator.internal.util.logging.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.logging.Logger;

@SpringBootApplication
public class PersonaApplication {
	private PersonaRepository personaRepository;

	public static void main(String[] args) {

		SpringApplication.run(PersonaApplication.class, args);

	}

	CommandLineRunner init(PersonaRepository personaRepository){
	     return args -> {

		    Persona persona1 = Persona.builder().
					nombre("Morena").apellidos("Arrieta").dni(45529965).
					build();
			personaRepository.save(persona1);
		 };
	}
}
